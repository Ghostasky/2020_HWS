from Crypto.Util.number import long_to_bytes,bytes_to_long
from Crypto.Cipher import AES
import hashlib
c=bytes_to_long('''Rln+hE0Nf9kSWar/czdRcu4I0M0vh5o3K9/eKyaXAHqa3dFjAAEzjD0fJ6CoQxs3TD8k4G4I3q5A
35Q9B7tmvn8dlBgUqAQ0LE6vSj/gz3hIZXTwYXx8OFztG0v4iV37bY3esCu2lv+FSjubwUPRzDz2
MiIbPSo4cPW1iDYnp/w='''.decode("base64"))

n=bytes_to_long('''hO8VxILES1zowG7lEZHSgvV3kWvnPXcm9Wy8AUiM/3w9390+KTzwFREQ3sJQf11TVgQV6Lq2oA5Y
027rwkmVGcjmMeUtr9R0aO2hQglLkfMgvtAI4tpaJ8EA7YE7mtq0a/RbOZxKI8Xp2HBCIpOnpMBd
FyG2JQk6ACnhKzOCRGk='''.decode("base64"))

ivc="JGlQ5/k4ePVbJZEL7aifrX6oQQLiTBOU7q5c0VwryUyBhYJyc6ZDWCYKZ/hHTMvS".decode("base64")
iv=ivc[0:16]
ac=ivc[16:]

print c
print n
print len(ivc)

k=hashlib.md5(long_to_bytes(c)).hexdigest()
aes=AES.new(k,AES.MODE_CBC,iv)
hp=aes.decrypt(ac)
hhp=bytes_to_long(hp+iv)

print hhp

import primefac
#from sage
p=0xa8fcddcb31e13809765fd087ca479e2e6d1b47d70713fe9d7d6ee84c2d7cd4ad246950e7f93878f55b25910beda89fadd9090491491412cc865e89ab0d6eb14bL
q=n/p
d=primefac.modinv(65537,(p-1)*(q-1)) % ( (p-1)*(q-1) )

print long_to_bytes(pow(c,d,n))