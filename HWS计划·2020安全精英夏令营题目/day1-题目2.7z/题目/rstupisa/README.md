﻿### Title
> rstupisa

### Description

#### cn
> 无

#### en
> None

### Category
> Crypto

### Deployment
> online

### Flag
> flag{n0_gg_n0_bb_a_stup1d_rs4}

### Score
> 400

### Hint
> None

### Attachment
> rstupisa.py

### Vulnerability
> None

### Tool
> pycrypto

### Tag
> rsa
