import flag
from os import urandom
from Crypto.Cipher import AES
import hashlib
from Crypto.Util.number import getPrime,long_to_bytes,bytes_to_long

def gen_arg():
    p=getPrime(512)
    q=getPrime(512)
    open("log.txt","w").write(hex(p)+"\n"+hex(q))
    n=p*q
    e=65537
    return n,e,p,q

def stupid_encrypt(m):
    n,e,p,q=gen_arg()
    c=pow(m,e,n)
    k=hashlib.md5(long_to_bytes(c)).hexdigest()
    iv=long_to_bytes(p)[32:48]
    m=long_to_bytes(p)[0:32]
    aes=AES.new(k,AES.MODE_CBC,iv)
    return c,n,iv+aes.encrypt(m)

def main():
    m = bytes_to_long(urandom(8) + flag.flag)
    c,n,x=stupid_encrypt(m)
    print long_to_bytes(c).encode("base64"),long_to_bytes(n).encode("base64"),x.encode("base64")

main()

'''output:
Rln+hE0Nf9kSWar/czdRcu4I0M0vh5o3K9/eKyaXAHqa3dFjAAEzjD0fJ6CoQxs3TD8k4G4I3q5A
35Q9B7tmvn8dlBgUqAQ0LE6vSj/gz3hIZXTwYXx8OFztG0v4iV37bY3esCu2lv+FSjubwUPRzDz2
MiIbPSo4cPW1iDYnp/w=
hO8VxILES1zowG7lEZHSgvV3kWvnPXcm9Wy8AUiM/3w9390+KTzwFREQ3sJQf11TVgQV6Lq2oA5Y
027rwkmVGcjmMeUtr9R0aO2hQglLkfMgvtAI4tpaJ8EA7YE7mtq0a/RbOZxKI8Xp2HBCIpOnpMBd
FyG2JQk6ACnhKzOCRGk=
JGlQ5/k4ePVbJZEL7aifrX6oQQLiTBOU7q5c0VwryUyBhYJyc6ZDWCYKZ/hHTMvS
'''