﻿### Title
> rseeya

### Description

#### cn
> 无

#### en
> None

### Category
> Crypto

### Deployment
> online

### Flag
> flag{a_boss_c0uldnt_fight_3_tigers}

### Score
> 400

### Hint
> None

### Attachment
> attachments.7z

### Vulnerability
> None

### Tool
> pycrypto

### Tag
> rsa
