from Crypto.Util.number import getPrime,long_to_bytes,bytes_to_long
from flag import flag
from os import urandom

def gen_arg(i):
    p=getPrime(1024)
    q=getPrime(1024)
    open("log"+str(i)+".txt","w").write(hex(p)+"\n"+hex(q))
    n=p*q
    e=7
    return n,e,p,q

def tiger_process(i,c,n):
    open("todolist_"+str(i)+".txt","w").write(hex(c)+"\n"+hex(n))

def boss_process():
    bossmessage=urandom(512/8)+flag
    for i in range(7):
        n,e,p,q=gen_arg(i)
        c=pow(bytes_to_long(bossmessage),e,n)
        tiger_process(i,c,n)

boss_process()