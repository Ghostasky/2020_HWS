from functools import reduce
import gmpy2 as gmpy
from Crypto.Util.number import long_to_bytes


def modinv(a, m):
    return int(gmpy.invert(gmpy.mpz(a), gmpy.mpz(m)))
nset = []
cset = []
for i in range(7):
    [cs, ns] = open("todolist_" + str(i) + ".txt", "rb").read().split()
    c = int(cs.strip()[2:-1], 16)
    n = int(ns.strip()[2:-1], 16)
    nset.append(n)
    cset.append(c)

def chinese_remainder(n, a):
    sum = 0
    prod = reduce(lambda a, b: a * b, n)
    for n_i, a_i in zip(n, a):
        p = prod // n_i
        sum += a_i * modinv(p, n_i) * p
    return int(sum % prod)

m = chinese_remainder(nset, cset)
print long_to_bytes(gmpy.iroot(m,7)[0])