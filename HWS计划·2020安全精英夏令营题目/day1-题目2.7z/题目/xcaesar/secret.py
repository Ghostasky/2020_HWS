m="flag{kaisamima}"
k=7