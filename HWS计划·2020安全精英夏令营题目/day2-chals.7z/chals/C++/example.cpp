#include <iostream>
using namespace std;

class Base
{
public:
    virtual int get_data1(){};
    virtual int get_data2(){};
};

class A : public Base
{
public: 
    int data_a;
    virtual int get_data1()
    {
        return data_a;
    }
    virtual int get_data2(){};
};

class B : public A
{
public:
    int data_b;
    virtual int get_data2()
    {
        return data_b + A::data_a;
    };
};

class Base2
{
public:
    virtual int get_base2_data1(){};
    virtual int get_base2_data2(){};
};

class C : public B, Base2
{
public:
    int base2_data1;
    int base2_data2;
    virtual int get_base2_data1()
    {
        return base2_data1;
    }
    virtual int get_base2_data2()
    {
        return base2_data2;
    }
};

int main()
{
    B *b = new B();
    Base *base = b;
    C *c = new C();
    b->data_b = 1;
    b->data_a = 2;
    c->base2_data1 = 3;
    c->base2_data2 = 4;

    cout << b->data_b << endl;
    cout << b->get_data2() << endl;
    cout << base->get_data1() << endl;

    cout << c->get_data1() << endl;
    cout << c->get_base2_data1() << endl;
    cout << c->data_b << endl;
    cout << c->base2_data1 << endl;
    cout << c->base2_data2 << endl;
    cout << "Hello world!" << endl;
}