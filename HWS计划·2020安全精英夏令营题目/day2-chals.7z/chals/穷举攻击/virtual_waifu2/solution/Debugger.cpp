﻿

#include <Windows.h>
#include <iostream>

BYTE Bp(LPVOID BpAddr);
void Recover(LPVOID Addr, BYTE data);

#define ProcessNameToDebug L"virtual_waifu2.exe"

STARTUPINFO si = {0};
PROCESS_INFORMATION pi = {0};
BYTE orgs[100] = {0};
int cur_pos = 0;
BYTE dst[] = {0x86, 0x5C, 0xB8, 0x46, 0x4C, 0xBD, 0x4A, 0xA3,
              0xBE, 0x4C, 0x8D, 0xA3, 0xBA, 0xF3, 0xA1, 0xAB,
              0xA2, 0xFA, 0xF9, 0xA4, 0xAE, 0x80, 0xFD, 0xAE};
BYTE trying_str[sizeof(dst) + 1] = {0};

void ProcessDebugEvent(DEBUG_EVENT *dbg_event, DWORD *dbg_status)
{
  switch (dbg_event->dwDebugEventCode)
  {
  case EXIT_THREAD_DEBUG_EVENT:
  {
    printf("The thread %d exited with code: %d\n", dbg_event->dwThreadId,
           dbg_event->u.ExitThread.dwExitCode);
    *dbg_status = DBG_CONTINUE;
    break;
  }
  case CREATE_THREAD_DEBUG_EVENT:
  {
    printf("Thread 0x%x (Id: %d) created at: 0x%x\n",
           dbg_event->u.CreateThread.hThread, dbg_event->dwThreadId,
           dbg_event->u.CreateThread.lpStartAddress);
    *dbg_status = DBG_CONTINUE;
    break;
  }
  case EXCEPTION_DEBUG_EVENT: // 异常消息
  {
    EXCEPTION_DEBUG_INFO &exception = dbg_event->u.Exception;
    PVOID &addr = exception.ExceptionRecord.ExceptionAddress;
    switch (exception.ExceptionRecord.ExceptionCode)
    {
    case STATUS_BREAKPOINT: // Same value as EXCEPTION_BREAKPOINT
      CONTEXT lcContext;
      lcContext.ContextFlags = CONTEXT_ALL;
      GetThreadContext(pi.hThread, &lcContext);
      if (addr == (PVOID)0x00401717)
      { // 00401717  | 33C9   | xor ecx,ecx

        BYTE current[sizeof(dst)] = {0};
        PVOID p_current = nullptr;
        ReadProcessMemory(pi.hProcess, (LPVOID)lcContext.Esp, &p_current,
                          sizeof(p_current), NULL);
        ReadProcessMemory(pi.hProcess, (LPVOID)p_current, &current,
                          sizeof(current), NULL);

        if (!memcmp(dst, current, cur_pos + 1))
        { // current position
          printf("Pos 0 ~ %d correct! ", cur_pos);
          char correct[sizeof(trying_str)] = {0};
          memcpy(correct, trying_str, cur_pos + 1);
          printf("%s\n", correct);
          if (cur_pos == sizeof(dst) - 1)
          {
            printf("Flag found!!!\n");
            lcContext.Eip--; // Move back one byte
            SetThreadContext(pi.hThread, &lcContext);
            Recover(addr, orgs[0]);
          }
          cur_pos++;
        }
        else
        {
          printf("Pos 0 ~ %d wrong. %x - %x\n", cur_pos, dst[cur_pos],
                 current[cur_pos]);
        }
        // 回到初始化的位置
        lcContext.Eip = 0x4010a8;
        SetThreadContext(pi.hThread, &lcContext);
        PVOID add_esp = (PVOID)0x4010B2;
        Bp(add_esp);

        // printf("Break point at 0x%p\n", addr);
      }
      if (addr == (PVOID)0x4010B2)
      {
        // 跳过栈平衡操作，并对输入进行重新设置
        lcContext.Eip += 2;
        SetThreadContext(pi.hThread, &lcContext);

        // 获取用户输入字符串的地址
        PVOID input_str_addr = (PVOID)(lcContext.Eax);
        // ReadProcessMemory(pi.hProcess, input_str_addr, &input_str_addr,
        // sizeof(input_str_addr), NULL); 爆破
        trying_str[cur_pos]++;
        // 设置为我们的 trying_str
        // printf("%p\n", input_str_addr);
        WriteProcessMemory(pi.hProcess, input_str_addr, trying_str,
                           sizeof(trying_str), NULL);
      }

      *dbg_status = DBG_CONTINUE;
      break;
    default:
      printf("Unhandled exception at %p.\n", addr);
      *dbg_status = DBG_EXCEPTION_NOT_HANDLED;
    }
  }
  default:
    *dbg_status = DBG_CONTINUE;
  }
  return;
}

void Recover(LPVOID Addr, BYTE data)
{
  WriteProcessMemory(pi.hProcess, Addr, &data, sizeof(BYTE), NULL);
  FlushInstructionCache(pi.hProcess, Addr, 1);
}

BYTE Bp(LPVOID BpAddr)
{
  BYTE INT3 = 0xcc;
  BYTE ORG = 0;
  ReadProcessMemory(pi.hProcess, BpAddr, &ORG, sizeof(BYTE), NULL);
  WriteProcessMemory(pi.hProcess, BpAddr, &INT3, sizeof(BYTE), NULL);
  FlushInstructionCache(pi.hProcess, BpAddr, 1);
  return ORG;
}

void SetBreakPoints() { orgs[0] = Bp((LPVOID)0x00401717); }

void CreateDebuggee()
{

  ZeroMemory(&si, sizeof(si));
  si.cb = sizeof(si);
  ZeroMemory(&pi, sizeof(pi));
  CreateProcess(ProcessNameToDebug, NULL, NULL, NULL, FALSE,
                DEBUG_ONLY_THIS_PROCESS, NULL, NULL, &si, &pi);
  /*
          specifying DEBUG_ONLY_THIS_PROCESS as the sixth parameter
     (dwCreationFlags). With this flag, we are asking the Windows OS to
     communicate this thread for all debugging events, including process
     creation/termination, thread creation/termination, runtime exceptions, and
     so on.
  */
}

int main()
{
  CreateDebuggee();
  SetBreakPoints();
  DEBUG_EVENT debug_event = {0};
  for (;;)
  {
    if (!WaitForDebugEvent(&debug_event, INFINITE))
      return 0;
    DWORD dbg_status;
    ProcessDebugEvent(&debug_event,
                      &dbg_status); // User-defined function, not API
    ContinueDebugEvent(debug_event.dwProcessId, debug_event.dwThreadId,
                       dbg_status
                       /*
                               if this event is not handled/resolved by the
                          debuggee. The debugger might just record this event,
                               notify the debugger-user, or do something else.
                       */
    );
  }
  std::cout << "Hello World!\n";
}
