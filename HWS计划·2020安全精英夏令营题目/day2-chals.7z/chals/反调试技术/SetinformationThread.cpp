#include <iostream>
#include <Windows.h>

using namespace std;

typedef enum _THREADINFOCLASS {
	ThreadBasicInformation, 
	ThreadTimes, 
	ThreadPriority,
	ThreadBasePriority, 
	ThreadAffinityMask, 
	ThreadImpersonationToken,
	ThreadDescriptorTableEntry, 
	ThreadEnableAlignmentFaultFixup, 
	ThreadEventPair, 
	ThreadQuerySetWin32StartAddress, 
	ThreadZeroTlsCell, 
	ThreadPerformanceCount, 
	ThreadAmILastThread, 
	ThreadIdealProcessor,
	ThreadPriorityBoost, 
	ThreadSetTlsArrayAddress,
	ThreadIsIoPending, 
	ThreadHideFromDebugger 
} THREAD_INFO_CLASS;

typedef NTSTATUS(NTAPI* ZwSetInformationThread)(
	IN HANDLE ThreadHandle,
	IN THREAD_INFO_CLASS ThreadInformaitonClass,
	IN PVOID ThreadInformation,
	IN ULONG ThreadInformationLength
);

void anti() {
	HANDLE hwnd;
	HMODULE hModule;
	hwnd = GetCurrentThread();
	hModule = LoadLibrary("ntdll.dll");
	ZwSetInformationThread myFunc;
	myFunc = (ZwSetInformationThread)GetProcAddress(hModule, "ZwSetInformationThread");
	myFunc(hwnd, ThreadHideFromDebugger, NULL, NULL);
}


int main()
{
	anti();
    std::cout << "Hello World!\n";
}
