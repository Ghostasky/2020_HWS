# From 3.2 text_file.py
def readline(self, line):
    while True:
        if self.join_lines:
            if line:
                continue
            if self:
                continue

        return line

while __name__ != '__main__':
    b = 4
