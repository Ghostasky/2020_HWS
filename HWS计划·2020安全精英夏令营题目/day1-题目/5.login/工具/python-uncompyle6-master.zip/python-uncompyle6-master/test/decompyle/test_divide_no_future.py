#from __future__ import division

print '  1 // 2   =', 1 // 2
print '1.0 // 2.0 =', 1.0 // 2.0
print '  1 /  2   =', 1 / 2
print '1.0 /  2.0 =', 1.0 / 2.0
