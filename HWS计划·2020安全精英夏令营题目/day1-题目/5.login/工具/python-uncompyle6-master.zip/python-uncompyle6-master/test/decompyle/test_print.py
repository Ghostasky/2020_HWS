# print.py -- source test pattern for print statements
#
# This simple program is part of the decompyle test suite.
#
# decompyle is a Python byte-code decompiler
# See http://www.goebel-consult.de/decompyle/ for download and
# for further information

print 1,2,3,4,5
a = b + 5
print 1,2,3,4,5
print 1,2,3,4,5
print
print
print 1,2,3,4,5
print
