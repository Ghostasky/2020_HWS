---
name: Feature Request
about: Tell us about a new feature that you would like to see in uncompyle6

---

## Description

<!-- Add a short description of the feature. This might
include same input and output. -->

## Background

<!-- Add any additional background for the
feature, for example: user scenarios, or the value of the feature. -->

## Tests
<!-- _This section is optional._

Add text with suggestions on how to test the feature,
if it is not obvious.
-->
